﻿$(function () {
	
	//
	//sticky menu
	//
	//scrollIntervalID = setInterval(stickMenu, 10);
	

	//
	//handle submenu when hovering on menu item
	//
    $(".main-menu ul > li > a").hover(function () {
        showSubMenu(this);
        
    }, function () {
        $(this).removeClass("hovered-anchor");
        var anchorItem = this;
        setTimeout(function () { hideSubMenu(anchorItem); }, 50);
    });

    // always display submenu when the mouse still over the submenu 
    $(".main-menu-sub .sub-menu").hover(function () {
        var menuItem = $(this).attr('id').replace("Sub", "");
        
        $("#" + menuItem).addClass("hovered-anchor");
        
    }, function () {
        var menuItemId = $(this).attr('id').replace("Sub", "");
        var menuItem = $("#" + menuItemId)[0];
        setTimeout(function () { hideSubMenu(menuItem); }, 50);

		$("#" + menuItemId).removeClass("hovered-anchor");
    });
    
    
    //
    // ===== Scroll to Top ====
    //
	$('#s4-workspace').scroll(function() {
	    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
	        $('#return-to-top').fadeIn(200);    // Fade in the arrow
	    } else {
	        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
	    }
	});
	$('#return-to-top').click(function() {      // When arrow is clicked
	    $('#s4-workspace').animate({
	        scrollTop : 0                       // Scroll to top of body
	    }, 500);
	});
	
	
	//
	//accordion
	//
	var allPanels = $('.accordion > .cd').hide();
	//openFirstPanel();
	$('.accordion > .ct > a').click(function() {
		//allPanels.slideUp();
		if($(this).parent().next().is(":visible"))
		{
			/*$('.accordion > .cd').slideUp();*/
			$(this).parent().next().slideUp();
		}
		else
		{
			/*$('.accordion > .cd').slideUp();*/
			$(this).parent().next().slideDown();
		}
		return false;
	});
	
	
	//
	//hide home link in main menu in the home page
	//
	if(IsHomePage())
	{
		$('div.main-menu ul li#home').hide();
	}
	
	
    
    //
    //adjust added .ExternalClass issue in inline style content
    //
    $('.wp-wrapper').parent().addClass('ExternalClass');
    
    //
    //make all images in page content responsive
    //
    $(".page-container .page-content img").addClass("img-fluid");
    
    
    //
    //search code
    //
    $("#btnOpenSearch").click(function(){
    	$(".search-bar").slideToggle(300);
    	$("#txtSearch" ).focus();
	});
	$("#btnOpenSearchMob").click(function(){
    	$(".search-bar").slideToggle(300);
    	$("#txtSearch" ).focus();
	});
	
    $("#btnSearch").click(function(){
    	search_aou();
    });
    $('#txtSearch').keyup(function(e){
    	if(e.keyCode == 13)
    	{
    		search_aou();
    	}
    });
    
    $('.header').click(function(event) {
	    if (!$(event.target).closest("#btnOpenSearch").length) {
	        $(".search-bar").slideUp(300);
	    }
	    if (!$(event.target).closest("#btnOpenMenuMob").length) {
	        //$(".menu-mob").slideUp(300);
	    }
	});
	$('.header-mob').click(function(event) {
	    if (!$(event.target).closest("#btnOpenSearchMob").length) {
	        $(".search-bar").slideUp(300);
	    }
	    if (!$(event.target).closest("#btnOpenMenuMob").length) {
	        //$(".menu-mob").slideUp(300);
	    }
	});
	
	
	
	//
	//this is for course catalouge search option
	//
	//override contains filter to be case insensitive
	jQuery.expr[':'].icontains = function (a, i, m) {
        return jQuery(a).text().toUpperCase()
            .indexOf(m[3].toUpperCase()) >= 0;
    };
    $("#btnSearchCourse").click(function () {
        SearchCourse();
    });
    $('#txtSearchCourse').keyup(function (e) {
        if (e.keyCode == 13) {
            SearchCourse();
        }
    });
    $("#btnClearSearchCourse").click(function () {
        ClearSearchCourse();
    });
	

	HighlightCurrentMenuItem();
	
	//enable bootstrap tooltip
	$('[data-toggle="tooltip"]').tooltip();
});

function showSubMenu(anchorItem) {
    var subMenuId = $(anchorItem).attr('id') + "Sub";

	$(".sub-menu[id!='" + subMenuId + "']").hide();
    
    var subMenuVisible = $("#" + subMenuId).is(":visible");
    if (!subMenuVisible) {
        setTimeout(function () {
            if ($(anchorItem).is(":hover"))
                $("#" + subMenuId).slideDown();
        }, 300);
    }
}

function hideSubMenu(anchorItem) {
    
    var subMenuId = $(anchorItem).attr('id') + "Sub";
    var isHoveredAnchor = ( $(anchorItem).hasClass('hovered-anchor') );
    
    if (!isHoveredAnchor) {
        $("#" + subMenuId).slideUp(50);
    }
}

function openFirstPanel()
{
  $('.accordion > dt:first-child').next().addClass('active').slideDown();
}

function IsHomePage()
{
	var url = window.location.href.toLowerCase();
	
	if(url.toString().indexOf('www.arabou.edu.sa/pages/default.aspx') > -1 || 
	   url.toString().indexOf('www.arabou.edu.sa/ar/pages/default.aspx') > -1)
	{
		return true;
	}
	else if (url.toString() == 'https://www.arabou.edu.sa' ||
	         url.toString() == 'https://www.arabou.edu.sa/ar')
	{
		return true;
	}
	else if (url.toString() == 'https://www.arabou.edu.sa/' ||
	         url.toString() == 'https://www.arabou.edu.sa/ar/')
	{
		return true;
	}
	else
	{
		return false;
	}
}

function search_aou()
{
	var searchString = $('#txtSearch').val().trim();
	if(searchString.length == 0)
		return;
		
	$('#txtSearch').val('');
	
	var rootWebUrl = window.location.host;
	
	var url = '/_layouts/15/osssearchresults.aspx?u=' + encodeURIComponent(rootWebUrl) + '&k=' + encodeURIComponent(searchString);
	
	//window.open(url, '_blank');
	window.location.href = url;
}

function HighlightCurrentMenuItem() {
    //var pathname = window.location.pathname.toLowerCase(); // Returns path only
    var url = window.location.href.toLowerCase().replace('https://www.arabou.edu.sa', '');     // Returns full URL

    $('#sidebar li a[href="' + url + '" i]').parent().addClass('active');
    
    //toggle if the current page inside submenu
    $('#sidebar li a[href="' + url + '" i]').closest('.collapse').toggle();
    $('#sidebar li a[href="' + url + '" i]').closest('.collapse').prev().attr("aria-expanded","true");
}



function SwitchToArabic()
{
	//return;
	var url = window.location.href;
	url = url.replace(".edu.sa",".edu.sa/ar");
	window.location.href = url;
}
function SwitchToEnglish()
{
	//return;
	var url = window.location.href;
	url = url.replace("/ar/","/");
	window.location.href = url;
}


/*
function stickMenu() {
  
  var sharepointBarsHeight = $("#s4-ribbonrow").height() + $("#suiteBarDelta").height() + $("#DeltaPageStatusBar").height();
  
  var mainMenuPos = $('.main-menu').offset();
  var mainMenuHeight = $('.main-menu').height();
  
  var mainMenuTop = mainMenuPos.top;
  
  if(sharepointBarsHeight)
  {
	  mainMenuTop = mainMenuTop - sharepointBarsHeight;
  }

  if ($(window).scrollTop() >= (mainMenuTop)) {
  	//alert('stick');
  	$('.main-menu').addClass('fixed');
    $(".main-menu").css("top", sharepointBarsHeight);
    
    $('.main-menu-sub').addClass('fixed');
    $(".main-menu-sub").css("top", sharepointBarsHeight + mainMenuHeight + 20);
  }
  else {
  	//alert('no stick');
  	$('.main-menu').removeClass('fixed');
  	$(".main-menu").css("top", "");
  }
}
*/



//
//this is for course catalouge search option
//
function SearchCourse() {
    var searchString = $('#txtSearchCourse').val().trim();

    if (searchString.length == 0) {
        $("div.course-item").fadeIn();
        return;
    }

    $("div.course-item").fadeOut();
    $("div.course-title:icontains('" + searchString + "')").parent().fadeIn();
}
function ClearSearchCourse() {
    $('#txtSearchCourse').val('');
    $("div.course-item").fadeIn();
}
